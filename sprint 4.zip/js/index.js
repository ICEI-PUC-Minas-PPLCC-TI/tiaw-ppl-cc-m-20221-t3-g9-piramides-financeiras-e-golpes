//dados do usuario
var userLogado = JSON.parse(localStorage.getItem('userLogado'))

let logado = document.querySelector('#logado')

//logado.innerHTML = `Olá ${userLogado.user}`

// if(localStorage.getItem('token') == null){
//     window.location.href = "index.html";
// }

function sair() {
    localStorage.removeItem('token')
    localStorage.removeItem('userLogado')
    localStorage.removeItem('todoList')
    window.location.href = "index.html";
}

//mostrar usuario no cabeçalho

console.log(userLogado)

var cabecalho = document.getElementById("navbar-items")
console.log(cabecalho)

if(!userLogado) {
    console.log("entrou")
} else {
    console.log("entrou")
    document.getElementById("navbar-items").innerHTML = `
        <li><a href="index.html" id="homenav">Início</a></li>
						<li><a href="noticias.html" id="blognav">Notícias</a></li>
						<li><a href="contact.html">Contato</a></li>
            <li><a href="#">Sobre</a></li>
            <li><a href="login.html" id="fullwidthnav">${userLogado.user}</a></li>
    `
}