/*let select = document.querySelector('#Opcoes')
console.log(select);

let value = select.options[select.selectedIndex].value;

let text = select.options[select.selectedIndex].text;

console.log(value, text)

function atualizouSelect() {
  let select = document.querySelector('#Opcoes');
  let optionValue = select.options[select.selectedIndex];
  let value = optionValue.value;

}
atualizouSelect()
*/


var myData = [
  { name: 'T1', value: 10 },
  { name: 'T2', value: 4 },
  { name: 'T3', value: 8 },
  { name: 'T4', value: 9 },
  { name: 'T12', value: 10 },
]



var pieData;
if(localStorage.getItem('pieData') != undefined){
  pieData = JSON.parse(localStorage.getItem('pieData'));
}
else{
  pieData = [
    { name: 'Não sabe se a falta informação sobre o assunto', y: 10 },
    { name: 'Acreditam que existe a falta de informação', y: 10 },
    { name: 'Acreditam que não existe a falta de informação', y: 10 },
  ]
  localStorage.setItem('pieData',JSON.stringify(pieData));
}

Highcharts.chart('container', {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie'
  },
  title: {
    text: 'Faça o seu voto abaixo'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %',
        style: {
          color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
        }
      }
    }
  },
  series: [{
    name: 'Votos',
    colorByPoint: true,
    data: pieData
  }]
});

function addVote1(){
  pieData[0].y++;
  localStorage.setItem('pieData',JSON.stringify(pieData));
  window.location.reload();
}
function addVote2(){
  pieData[1].y++;
  localStorage.setItem('pieData',JSON.stringify(pieData));
  window.location.reload();
}
function addVote3(){
  pieData[2].y++;
  localStorage.setItem('pieData',JSON.stringify(pieData));
  window.location.reload();
}

document.querySelectorAll('#container g.highcharts-series-group g.highcharts-pie-series path')[0].addEventListener('click',addVote1);
document.querySelectorAll('#container g.highcharts-series-group g.highcharts-pie-series path')[1].addEventListener('click',addVote2);
document.querySelectorAll('#container g.highcharts-series-group g.highcharts-pie-series path')[2].addEventListener('click',addVote3);
